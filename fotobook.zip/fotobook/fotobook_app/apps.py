from django.apps import AppConfig


class FotobookAppConfig(AppConfig):
    name = 'fotobook_app'
